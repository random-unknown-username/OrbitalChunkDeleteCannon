package net.hardat.chunkdeletecannon;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.hardat.chunkdeletecannon.item.ChunkDeleteRodItem;
import net.hardat.chunkdeletecannon.world.ChunkDeletionScheduler;
import net.minecraft.class_12099;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.Collection;
import java.util.List;

public final class ChunkDeleteCannonMod implements ModInitializer {
    public static final String MOD_ID = "chunkdeletecannon";
    public static final class_2960 CHUNK_DELETE_ROD_ID = class_2960.method_60655(MOD_ID, "chunk_delete_rod");
    public static final class_5321<class_1792> CHUNK_DELETE_ROD_KEY = class_5321.method_29179(class_7924.field_41197, CHUNK_DELETE_ROD_ID);

    public static final class_1792 CHUNK_DELETE_ROD = class_2378.method_39197(
            class_7923.field_41178,
            CHUNK_DELETE_ROD_KEY,
            new ChunkDeleteRodItem(new class_1792.class_1793()
                    .method_63686(CHUNK_DELETE_ROD_KEY)
                    .method_7895(1)
                    .method_7894(class_1814.field_8904)
                    .method_24359())
    );

    @Override
    public void onInitialize() {
        ChunkDeletionScheduler.register();
        registerCommands();
    }

    private static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
                class_2170.method_9247("chunkrod")
                        .requires(source -> source.method_75037().hasPermission(class_12099.field_63210))
                        .then(class_2170.method_9247("give")
                                .executes(context -> giveRod(context.getSource(), List.of(context.getSource().method_9207())))
                                .then(class_2170.method_9244("targets", class_2186.method_9308())
                                        .executes(context -> giveRod(context.getSource(), class_2186.method_9312(context, "targets")))))
        ));
    }

    private static int giveRod(class_2168 source, Collection<class_3222> targets) {
        for (class_3222 player : targets) {
            class_1799 stack = new class_1799(CHUNK_DELETE_ROD);
            if (!player.method_7270(stack)) {
                player.method_7328(stack, false);
            }
        }

        String name = targets.size() == 1
                ? targets.iterator().next().method_5477().getString()
                : targets.size() + " players";
        source.method_9226(() -> class_2561.method_43470("Gave a Chunk Delete Rod to " + name + "."), true);
        return Command.SINGLE_SUCCESS;
    }
}
