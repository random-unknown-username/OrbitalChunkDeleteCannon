package net.hardat.chunkdeletecannon.world;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Objects;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;

public final class ChunkDeletionScheduler {
    private static final int BLOCKS_PER_TICK = 4096;
    private static final Queue<DeletionTask> TASKS = new ArrayDeque<>();
    private static final Set<String> QUEUED_KEYS = new HashSet<>();
    private static boolean registered = false;

    private ChunkDeletionScheduler() {
    }

    public static void register() {
        if (registered) {
            return;
        }
        registered = true;
        ServerTickEvents.END_SERVER_TICK.register(ChunkDeletionScheduler::tick);
    }

    public static boolean enqueue(class_3218 level, class_1923 chunkPos, class_3222 owner) {
        String key = key(level.method_27983(), chunkPos);
        if (!QUEUED_KEYS.add(key)) {
            return false;
        }

        TASKS.add(new DeletionTask(level.method_27983(), chunkPos, owner.method_5667(), key));
        return true;
    }

    private static void tick(MinecraftServer server) {
        int processed = 0;

        while (processed < BLOCKS_PER_TICK && !TASKS.isEmpty()) {
            DeletionTask task = TASKS.peek();
            class_3218 level = server.method_3847(task.dimension());

            if (level == null) {
                finish(server, Objects.requireNonNull(TASKS.poll()), "Skipped chunk deletion because the dimension is no longer loaded.");
                continue;
            }

            int minY = level.method_31607();
            int height = level.method_31605();
            int totalBlocks = 16 * 16 * height;
            class_2338.class_2339 mutablePos = new class_2338.class_2339();

            while (processed < BLOCKS_PER_TICK && task.nextIndex() < totalBlocks) {
                int index = task.nextIndex();
                task.advance();

                int localX = index & 15;
                int localZ = (index >> 4) & 15;
                int y = minY + (index >> 8);

                mutablePos.method_10103(task.chunkPos().method_8326() + localX, y, task.chunkPos().method_8328() + localZ);
                if (!level.method_22347(mutablePos)) {
                    level.method_8652(mutablePos, class_2246.field_10124.method_9564(), 3);
                }

                processed++;
            }

            if (task.nextIndex() >= totalBlocks) {
                finish(server, Objects.requireNonNull(TASKS.poll()), "Chunk deletion complete.");
            }
        }
    }

    private static void finish(MinecraftServer server, DeletionTask task, String message) {
        QUEUED_KEYS.remove(task.queueKey());
        class_3222 owner = server.method_3760().method_14602(task.ownerUuid());
        if (owner != null) {
            owner.method_7353(class_2561.method_43470(message), true);
        }
    }

    private static String key(class_5321<class_1937> dimension, class_1923 chunkPos) {
        return dimension.method_29177() + ":" + chunkPos.field_9181 + "," + chunkPos.field_9180;
    }

    private static final class DeletionTask {
        private final class_5321<class_1937> dimension;
        private final class_1923 chunkPos;
        private final UUID ownerUuid;
        private final String queueKey;
        private int nextIndex;

        private DeletionTask(class_5321<class_1937> dimension, class_1923 chunkPos, UUID ownerUuid, String queueKey) {
            this.dimension = dimension;
            this.chunkPos = chunkPos;
            this.ownerUuid = ownerUuid;
            this.queueKey = queueKey;
            this.nextIndex = 0;
        }

        private class_5321<class_1937> dimension() {
            return dimension;
        }

        private class_1923 chunkPos() {
            return chunkPos;
        }

        private UUID ownerUuid() {
            return ownerUuid;
        }

        private String queueKey() {
            return queueKey;
        }

        private int nextIndex() {
            return nextIndex;
        }

        private void advance() {
            nextIndex++;
        }
    }
}
