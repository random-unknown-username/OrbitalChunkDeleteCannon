package net.hardat.chunkdeletecannon.item;

import net.hardat.chunkdeletecannon.world.ChunkDeletionScheduler;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1787;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public final class ChunkDeleteRodItem extends class_1787 {
    private static final double TARGET_RANGE = 128.0D;

    public ChunkDeleteRodItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        if (level.method_8608()) {
            return class_1269.field_5812;
        }

        if (!(level instanceof class_3218 serverLevel) || !(user instanceof class_3222 serverPlayer)) {
            return class_1269.field_5814;
        }

        class_3965 hit = raycast(level, user);
        if (hit.method_17783() != class_239.class_240.field_1332) {
            serverPlayer.method_7353(class_2561.method_43470("Aim at a block within " + (int) TARGET_RANGE + " blocks."), true);
            return class_1269.field_5814;
        }

        class_1923 chunkPos = new class_1923(hit.method_17777());
        boolean queued = ChunkDeletionScheduler.enqueue(serverLevel, chunkPos, serverPlayer);
        if (!queued) {
            serverPlayer.method_7353(class_2561.method_43470("That chunk is already being deleted."), true);
            return class_1269.field_5814;
        }

        if (!serverPlayer.method_31549().field_7477) {
            stack.method_7934(1);
        }

        serverPlayer.method_7353(class_2561.method_43470("Queued chunk deletion at chunk " + chunkPos.field_9181 + ", " + chunkPos.field_9180 + "."), true);
        return class_1269.field_5812;
    }

    private static class_3965 raycast(class_1937 level, class_1657 user) {
        class_243 start = user.method_33571();
        class_243 end = start.method_1019(user.method_5828(1.0F).method_1021(TARGET_RANGE));
        return level.method_17742(new class_3959(start, end, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, user));
    }
}
